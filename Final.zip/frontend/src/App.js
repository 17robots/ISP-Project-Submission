import React, { useState } from 'react'
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom'

import './App.css';
import AuthContext from './context/auth-context'
import HomePage from './components/Pages/HomePage'
import Clients from './components/Pages/Clients'
import Projects from './components/Pages/Projects'
import Invoices from './components/Pages/Invoices'
import Sidebar from './components/Sidebar'
import Video from './components/Pages/Video'


function App() {
  const [token, setToken] = useState(null)
  const [userId, setUserId] = useState(null)

  const checkIsLoggedIn = () => {
    const expiration = parseInt(localStorage.getItem('expiration'))
    if (expiration) {
      if (new Date().getTime() < expiration) {
        setToken(parseInt(localStorage.getItem('token')))
        setUserId(parseInt(localStorage.getItem('userId')))
        return true
      } else {
        localStorage.removeItem('token')
        localStorage.removeItem('userId')
        localStorage.removeItem('expiration')
        return false
      }
    }
    return false
  }

  const login = (token, userId, tokenExpiration) => {
    setToken(token)
    setUserId(userId)
    localStorage.setItem('token', token)
    localStorage.setItem('userId', userId)
    localStorage.setItem('expiration', new Date().getTime() + tokenExpiration)
  }

  const logout = () => {
    console.log("logging out")
    setToken(null)
    setUserId(null)
    localStorage.removeItem('token')
    localStorage.removeItem('userId')
    localStorage.removeItem('expiration')
  }

  return (
    <div className="App">
      <BrowserRouter>
        <React.Fragment>
          <AuthContext.Provider value={{ token, userId, login, logout, checkIsLoggedIn }}>
            <Sidebar />
            <main className="main-content">
              <Switch>
                {!token && <Redirect from="/clients" to="/" exact />}
                {!token && <Redirect from="/projects" to="/" exact />}
                {!token && <Redirect from="/invoices" to="/" exact />}
                <Route path="/clients" component={Clients} exact />
                <Route path="/video" component={Video} exact />
                <Route path="/projects" component={Projects} exact />
                <Route path="/invoices" component={Invoices} exact />
                <Route path="/" component={HomePage} exact />
              </Switch>
            </main>
          </AuthContext.Provider>
        </React.Fragment>
      </BrowserRouter>
    </div>
  );
}

export default App;
