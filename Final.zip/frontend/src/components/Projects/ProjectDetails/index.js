import React from 'react'
import Backdrop from '../../Backdrop'
import Modal from '../../Modal/'
import AuthContext from '../../../context/auth-context'
import './index.css'

export default class ProjectDetails extends React.Component {
  static contextType = AuthContext
  constructor(props) {
    super(props)

    this.milestoneNameEl = React.createRef()
    this.milestoneDueDateEl = React.createRef()

    this.taskTitleEl = React.createRef()
    this.taskMilestoneEl = React.createRef()
    this.taskDescriptionEl = React.createRef()
    this.taskCompleteEl = React.createRef()
  }

  state = {
    tasks: [],
    milestones: [],
    selectedTask: null,
    selectedMilestone: null,
    isEditingTask: false,
    isCreatingTask: false,
    isEditingMilestone: false,
    isCreatingMilestone: false,
    client: {},
    activeTab: 'Tasks'
  }

  componentDidMount() {
    // here we fetch the milestones, tasks, and the client from the db
    let body = {
      action: "getTasks",
      options: {
        projectId: this.props.project.id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ tasks: resData })
        }
      })

    body = {
      action: "getMilestones",
      options: {
        projectId: this.props.project.id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ milestones: resData })
        }
      })

    body = {
      action: "getClient",
      id: this.props.project.clientId
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ client: resData })
        }
      })
  }

  startCreateTaskOnMilestone = id => {
    this.setState(prevState => {
      const selectedMilestone = prevState.milestones.find(e => e.id === id)
      return { isCreatingTask: true, selectedMilestone }
    })
  }

  stopCreateTaskOnMilestone = () => {
    this.setState({ isCreatingTask: false, selectedMilestone: null })
  }

  startCreateTask = () => {
    this.setState({ isCreatingTask: true })
  }

  stopCreateTask = () => {
    this.setState({ isCreatingTask: false })
  }

  toggleComplete = id => {
    this.setState(prevState => {
      const selectedTask = prevState.tasks.find(e => e.id === id)
      return { selectedTask }
    })

    const body = {
      action: "updateTask",
      id,
      projectid: this.state.selectedTask.projectId,
      milestoneid: this.state.selectedTask.milestoneId,
      title: this.state.selectedTask.title,
      description: this.state.selectedTask.description,
      completed: !this.state.selectedTask.completed
    }
  }

  addTask = () => {
    const body = {
      action: "addTask",
      creatorid: this.context.userId,
      projectid: this.props.project.id,
      milestoneid: this.state.selectedMilestone ? this.state.selectedMilestone.id : this.taskMilestoneEl.current.value,
      title: this.taskTitleEl.current.value,
      description: this.taskDescriptionEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { tasks: prevState.tasks.concat(resData), isCreatingTask: false, selectedMilestone: null }
          })
        }
      })
  }

  startEditTask = id => {
    this.setState(prevState => {
      const selectedTask = prevState.tasks.find(e => e.id === id)
      return { isEditingTask: true, selectedTask }
    })

  }

  stopEditTask = () => {
    this.setState({ isEditingTask: false, selectedTask: null })
  }

  editTask = () => {
    const body = {
      action: "updateTask",
      id: this.state.selectedTask.id,
      projectid: this.props.project.id,
      milestoneid: this.taskMilestoneEl.current.value,
      title: this.taskTitleEl.current.value,
      description: this.taskDescriptionEl.current.value,
      completed: this.taskCompleteEl.current.checked ? 1 : 0
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { tasks: prevState.tasks.map(task => task.id === prevState.selectedTask.id ? resData : task), isEditingTask: false, selectedTask: null }
          })
        }
      })

  }

  deleteTask = id => {
    const body = {
      action: "deleteTask",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ tasks: prevState.tasks.filter(task => task.id !== id) }))
        }
      })
  }

  startCreateMilestone = () => {
    this.setState({ isCreatingMilestone: true })

  }

  stopCreateMilestone = () => {
    this.setState({ isCreatingMilestone: false })
  }

  addMilestone = () => {
    const body = {
      action: "addMilestone",
      creatorid: this.context.userId,
      projectid: this.props.project.id,
      milestonename: this.milestoneNameEl.current.value,
      duedate: this.milestoneDueDateEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { milestones: prevState.milestones.concat(resData), isCreatingMilestone: false }
          })
        }
      })
  }

  startEditMilestone = id => {
    this.setState(prevState => {
      const selectedMilestone = prevState.milestones.find(e => e.id === id)
      return { isEditingMilestone: true, selectedMilestone }
    })
  }

  stopEditMilestone = () => {
    this.setState({ isEditingMilestone: false, selectedMilestone: null })
  }

  editMilestone = () => {
    const body = {
      action: "updateMilestone",
      id: this.state.selectedMilestone.id,
      projectid: this.props.project.id,
      milestonename: this.milestoneNameEl.current.value,
      duedate: this.milestoneDueDateEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { milestones: prevState.milestones.map(milestone => milestone.id === prevState.selectedMilestone.id ? resData : milestone), isEditingMilestone: false, selectedMilestone: null }
          })
        }
      })
  }

  deleteMilestone = id => {
    const body = {
      action: "deleteMilestone",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ milestones: prevState.milestones.filter(milestone => milestone.id !== id) }))
        }
      })
  }

  render() {
    return (
      <div className="project-details">
        {(this.state.isCreatingMilestone || this.state.isCreatingTask || (this.state.isEditingMilestone && this.state.selectedMilestone) || (this.state.isEditingTask && this.state.selectedTask)) && <Backdrop />}
        {/* Create Milestone Modal */}

        {
          this.state.isCreatingMilestone &&
          <Modal
            title="Add Milestone"
            canCancel
            canConfirm
            confirmText="Add"
            onCancel={this.stopCreateMilestone}
            onConfirm={this.addMilestone}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="milestoneName">Name</label>
                <input type="text" name="milestoneName" ref={this.milestoneNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="milestoneDueDate">Due Date</label>
                <input type="date" name="milestoneDueDate" ref={this.milestoneDueDateEl} required />
              </div>

            </form>
          </Modal>
        }

        {/* Edit Milestine Modal */}

        {
          (this.state.isEditingMilestone && this.state.selectedMilestone) &&
          <Modal
            title="Edit Milestone"
            canCancel
            canConfirm
            confirmText="Save"
            onCancel={this.stopEditMilestone}
            onConfirm={this.editMilestone}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="milestoneName">Name</label>
                <input type="text" name="milestoneName" defaultValue={this.state.selectedMilestone.milestonename} ref={this.milestoneNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="milestoneDueDate">Due Date</label>
                <input type="date" name="milestoneDueDate" defaultValue={this.state.selectedMilestone.datedue} ref={this.milestoneDueDateEl} required />
              </div>

            </form>
          </Modal>
        }

        {/* Create Task Modal */}

        {
          this.state.isCreatingTask &&
          <Modal
            title={this.state.selectedMilestone ? "Add Task For " + this.state.selectedMilestone.milestonename : "Add Task"}
            canCancel
            canConfirm
            onConfirm={this.addTask}
            onCancel={this.state.selectedMilestone ? this.stopCreateTaskOnMilestone : this.stopCreateTask}
            confirmText="Add"
          >
            <form className="input-form">
              {
                !this.state.selectedMilestone &&
                <div className="form-control">
                  <label htmlFor="taskMilestone">Milestone</label>
                  <select ref={this.taskMilestoneEl}>
                    <option value="null"></option>
                    {this.state.milestones.map(milestone => <option value={milestone.id}>{milestone.milestonename}</option>)}
                  </select>
                </div>
              }

              <div className="form-control">
                <label htmlFor="taskTitle">Name</label>
                <input type="text" name="taskTitle" ref={this.taskTitleEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="taskDescription">Description</label>
                <input type="text" name="taskTitle" ref={this.taskDescriptionEl} required />
              </div>

            </form>
          </Modal>
        }

        {/* Edit Task Modal */}
        {
          (this.state.isEditingTask && this.state.selectedTask) &&
          <Modal
            title="Edit Task"
            canCancel
            canConfirm
            onConfirm={this.editTask}
            onCancel={this.stopEditTask}
            confirmText="Save"
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="taskMilestone">Milestone</label>
                <select ref={this.taskMilestoneEl} defaultValue={this.state.selectedTask.milestoneId}>
                  <option value="null"></option>
                  {this.state.milestones.map(milestone => <option value={milestone.id}>{milestone.milestonename}</option>)}
                </select>
              </div>

              <div className="form-control">
                <label htmlFor="taskTitle">Name</label>
                <input type="text" defaultValue={this.state.selectedTask.title} name="taskTitle" ref={this.taskTitleEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="taskDescription">Description</label>
                <input type="text" defaultValue={this.state.selectedTask.description} name="taskTitle" ref={this.taskDescriptionEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="taskComplete">Completed</label>
                <input type="checkbox" defaultChecked={this.state.selectedTask.completed} name="taskComplete" ref={this.taskCompleteEl} required />
              </div>

            </form>
          </Modal>
        }

        <button onClick={(e) => { this.props.deselect(); e.stopPropagation() }}>Back</button>
        <h1>{this.props.project.name}</h1>
        <h3>{this.props.project.description}</h3>
        <h3>Client: {this.state.client.clientname} </h3>
        {this.props.project.dueDate ? <h3>Due: {this.props.project.dueDate}</h3> : ''}
        <h3>Payment Type: {this.props.project.paymentType}</h3>
        {
          this.props.project.paymentType === 'Fixed' ?
            <h3> Price: {this.props.project.rate}</h3>
            :
            <div>
              <h3> Estimated Hours: {this.props.project.estimatedHours}</h3>
              <h3> Rate: {this.props.project.rate}</h3>
            </div>
        }
        <h3>Total Invoiced: {this.props.project.totalInvoiced}</h3>
        {this.props.project.closed === "1" ? <h3>Closed</h3> : ''}
        <div>
          <button onClick={this.startCreateMilestone}>Add Milestone</button>
          <button onClick={this.startCreateTask}>Add Task</button>
        </div>
        <div className="tabs">
          <button className={this.state.activeTab === 'Tasks' ? "tab active" : "tab"} onClick={e => { this.setState({ activeTab: 'Tasks' }); e.stopPropagation() }}>Tasks</button>
          <button className={this.state.activeTab !== 'Tasks' ? "tab active" : "tab"} onClick={e => { this.setState({ activeTab: 'Milestones' }); e.stopPropagation() }}>Milestones</button>
        </div>
        {
          this.state.activeTab === 'Tasks' ?
            <div>
              {
                this.state.tasks.length > 0 ?
                  <ul className="task-list">
                    {this.state.tasks.map(task => {
                      return (
                        <li onClick={() => { this.startEditTask(task.id) }}>
                          <p>{task.title}</p>
                          <p>{task.description}</p>
                          {this.state.milestones.find(e => e.id === task.milestoneId) ? this.state.milestones.find(e => e.id === task.milestoneId).milestonename : 'No Milestone'}
                          <button onClick={e => { this.startEditTask(task.id); e.stopPropagation() }}>Edit</button>
                          <button onClick={e => { this.deleteTask(task.id); e.stopPropagation() }}>Delete</button>
                        </li>
                      )
                    })}
                  </ul>
                  :
                  <h2>No Tasks. Add Some To Get Started!</h2>
              }
            </div>
            :
            <div>
              {
                this.state.milestones.length > 0 ?
                  <ul>
                    {
                      this.state.milestones.map(milestone => {
                        return (
                          <li className="milestone">
                            <h2>{milestone.milestonename} - {milestone.datedue} <button onClick={e => { this.startEditMilestone(milestone.id); e.stopPropagation() }}>Edit Milestone</button><button onClick={e => { this.deleteMilestone(milestone.id); e.stopPropagation() }}>Delete Milestone</button></h2>
                            {
                              this.state.tasks.filter(task => task.milestoneId === milestone.id).length > 0 ?
                                <div>
                                  <ul className="milestone-tasks">
                                    {
                                      this.state.tasks.filter(task => task.milestoneId == milestone.id).map(task => {
                                        return (
                                          <li>
                                            <p>{task.title}</p>
                                            <p>{task.description}</p>
                                            <button onClick={() => { this.startEditTask(task.id) }}>Edit</button>
                                            <button>Delete</button>
                                          </li>
                                        )
                                      })
                                    }
                                  </ul>
                                  <button onClick={e => { this.startCreateTaskOnMilestone(milestone.id); e.stopPropagation() }}>Add Task To {milestone.milestonename}</button>
                                </div>
                                :
                                <div>
                                  <h3>No Tasks For {milestone.milestonename}, Please add one</h3>
                                  <button onClick={e => { this.startCreateTaskOnMilestone(milestone.id); e.stopPropagation() }}>Add Task To {milestone.milestonename}</button>
                                </div>
                            }
                          </li>
                        )
                      })
                    }
                  </ul>
                  :
                  <h2>No Milestones. Please Add Some or Switch Tabs</h2>
              }
              <h2>Other Tasks</h2>
              {
                this.state.tasks.filter(task => task.milestoneId === null || task.milestoneId === 'null').length > 0 ?
                  <ul>
                    {
                      this.state.tasks.filter(task => task.milestoneId === null || task.milestoneId === 'null').map(task => {
                        return (
                          <li>
                            {task.title}
                            {task.description}
                            <button onClick={() => { this.startEditTask(task.id) }}>Edit</button>
                            <button>Delete</button>
                          </li>
                        )
                      })
                    }
                  </ul>
                  :
                  <h3>No Other Tasks. Please Add More Or Switch Tabs</h3>
              }

            </div>
        }
      </div>
    )
  }
}