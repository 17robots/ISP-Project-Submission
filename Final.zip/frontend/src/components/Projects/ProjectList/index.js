import React from 'react'

const projectList = props => {
  const handleDelete = (e, id) => {
    props.delete(id)
    e.stopPropagation()
  }

  const handleEdit = (e, id) => {
    props.edit(id)
    e.stopPropagation()
  }

  const handleSelect = (e, id) => {
    props.select(id)
    e.stopPropagation()
  }
  return (
    <ul>
      {
        props.projects.map(project => (
          <li key={project.id} onClick={e => handleSelect(e, project.id)}>
            {project.name}
            <button onClick={e => handleEdit(e, project.id)}>Edit</button>
            <button onClick={e => handleDelete(e, project.id)}>Delete</button>
          </li>
        ))
      }
    </ul>
  )
}

export default projectList