import React from 'react'
import AuthContext from '../../context/auth-context'

export default class Invoices extends React.Component {
  static contextType = AuthContext
  constructor(props) {
    super(props)
    this.selectedTasks = React.createRef()
  }

  state = {
    availableClients: [],
    availableProjects: [],
    availableTasks: [],
    selectedClient: null,
    selectedProject: null,
    selectedTasks: [],
    availableMilestones: []
  }

  componentDidMount() {
    const body = {
      action: "getClients",
      options: {
        creatorid: this.context.userId
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ availableClients: resData })
        }
      })
  }

  switchClient = id => {
    this.setState(prevState => {
      const selectedClient = prevState.availableClients.find(e => e.id === id)
      return { selectedClient }
    })
    this.updateProjects(id)
  }

  switchProject = id => {
    this.setState(prevState => {
      const selectedProject = prevState.availableProjects.find(e => e.id === id)
      return { selectedProject }
    })
    this.updateTasks(id)
  }

  updateProjects = id => {
    const body = {
      action: "getProjects",
      options: {
        clientId: id
      }
    }

    console.log(body)

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ availableProjects: resData })
        }
      })
  }

  updateTasks = id => {
    let body = {
      action: "getTasks",
      options: {
        projectId: id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ availableTasks: resData })
        }
      })

    body = {
      action: "getMilestones",
      options: {
        projectId: id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ availableMilestones: resData })
        }
      })
  }

  generateInvoice = () => {
    if (!this.state.selectedClient) return
    const selected = []
    for (let option of this.selectedTasks.current.options) {
      if (option.selected) selected.push(option.value)
    }

  }



  render() {
    return (
      <div className="invoices">
        <h1>Generate Invoice</h1>
        <form onSubmit={e => e.preventDefault()}>
          <div className="invoice-control"></div>
          <label htmlFor="client">Client</label>
          <select onChange={e => this.switchClient(e.target.value)}>
            <option value="null"></option>
            {this.state.availableClients.map(client => <option value={client.id}>{client.clientname}</option>)}
          </select>

          {
            this.state.selectedClient &&
            <div className="invoice-control">
              <label htmlFor="client">Project</label>
              <select onChange={e => { this.switchProject(e.target.value) }}>
                <option value="null"></option>
                {this.state.availableProjects.map(project => <option value={project.id}>{project.name}</option>)}
              </select>
            </div>
          }

          {
            this.state.selectedProject &&
            <div>
              <div className="invoice-control">
                <label htmlFor="client">Tasks</label>
                <select multiple ref={this.selectedTasks}>
                  {
                    this.state.availableTasks.map(task => {
                      return (
                        <option value={task.id}>
                          {task.title} - {task.completed === "1" ? "complete" : "incomplete"}
                          {task.milestoneId ? this.state.availableMilestones.find(e => e.id === task.milestoneId) ? '; ' + this.state.availableMilestones.find(e => e.id === task.milestoneId).milestonename : '' : ''}
                        </option>
                      )
                    })
                  }
                </select>
              </div>
              <button onClick={this.generateInvoice}>Generate Invoice</button>
            </div>
          }
        </form>
      </div>
    )
  }
}