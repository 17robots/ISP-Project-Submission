import React from 'react'
import AuthContext from '../../context/auth-context'
import ClientList from '../Clients/ClientList'
import ClientDetails from '../Clients/ClientDetails'
import Backdrop from '../Backdrop'
import Modal from '../Modal'
import Spinner from '../Spinner'
import './index.css'

export default class Clients extends React.Component {
  static contextType = AuthContext

  constructor(props) {
    super(props)
    this.clientNameEl = React.createRef()
    this.clientPhoneEl = React.createRef()
    this.clientEmailEl = React.createRef()
    this.clientAddressEl = React.createRef()
  }

  state = {
    selectedClient: false,
    isEditing: false,
    isCreating: false,
    clients: [],
    isLoading: false
  }

  selectClient = id => {
    this.setState(prevState => {
      const selectedClient = prevState.clients.find(e => e.id === id)
      return { selectedClient }
    })
  }

  deselectClient = () => {
    this.setState({ selectedClient: null })
  }

  startCreate = () => {
    this.setState({ isCreating: true })
  }

  stopCreate = () => {
    this.setState({ isCreating: false })
  }

  addClient = () => {
    const body = {
      action: "addClient",
      creatorid: this.context.userId,
      clientname: this.clientNameEl.current.value,
      clientaddress: this.clientAddressEl.current.value,
      clientphone: this.clientPhoneEl.current.value,
      clientemail: this.clientEmailEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { clients: prevState.clients.concat(resData), isCreating: false }
          })
        }
      })

  }

  startEdit = id => {
    this.setState(prevState => {
      const selectedClient = prevState.clients.find(e => e.id === id)
      return { isEditing: true, selectedClient }
    })
  }

  stopEdit = () => {
    this.setState({ isEditing: false, selectedClient: null })
  }

  editClient = () => {
    const body = {
      action: "updateClient",
      id: this.state.selectedClient.id,
      clientname: this.clientNameEl.current.value,
      clientaddress: this.clientAddressEl.current.value,
      clientphone: this.clientPhoneEl.current.value,
      clientemail: this.clientEmailEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { isEditing: false, clients: prevState.clients.map(client => client.id === prevState.selectedClient.id ? resData : client) }
          })
        }
      })
  }

  deleteClient = id => {
    const body = {
      action: "deleteClient",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ clients: prevState.clients.filter(client => client.id !== id) }))
        }
      })
  }

  componentDidMount() {
    this.setState({ isLoading: true })
    const body = {
      action: "getClients",
      options: {
        creatorid: this.context.userId
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ clients: resData, isLoading: false })
        }
      })
  }

  render() {
    return (
      <div className="clients">
        { ((this.state.isEditing && this.state.selectedClient) || this.state.isCreating) && <Backdrop />}
        {/* The Create CLient Modal */}
        {
          this.state.isCreating &&
          <Modal
            title="Add Client"
            canCancel
            canConfirm
            confirmText="Add Client"
            onCancel={this.stopCreate}
            onConfirm={this.addClient}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="clientName">Client Name</label>
                <input type="text" name="clientName" ref={this.clientNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientPhone">Client Phone</label>
                <input type="phone" name="clientPhone" ref={this.clientPhoneEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientEmail">Client Email</label>
                <input type="clientEmail" name="clientEmail" ref={this.clientEmailEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientAddress">Client Address</label>
                <input type="text" name="clientAddress" ref={this.clientAddressEl} required />
              </div>

            </form>
          </Modal>
        }

        {/* The Edit Client Modal */}
        {
          (this.state.isEditing && this.state.selectedClient) &&
          <Modal
            title="Edit Client"
            canCancel
            canConfirm
            confirmText="Save Changes"
            onCancel={this.stopEdit}
            onConfirm={this.editClient}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="clientName">Client Name</label>
                <input type="text" name="clientName" defaultValue={this.state.selectedClient.clientname} ref={this.clientNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientPhone">Client Phone</label>
                <input type="phone" name="clientPhone" defaultValue={this.state.selectedClient.clientphone} ref={this.clientPhoneEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientEmail">Client Email</label>
                <input type="clientEmail" name="clientEmail" defaultValue={this.state.selectedClient.clientemail} ref={this.clientEmailEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="clientAddress">Client Address</label>
                <input type="text" name="clientAddress" defaultValue={this.state.selectedClient.address} ref={this.clientAddressEl} required />
              </div>

            </form>
          </Modal>
        }
        {
          (this.state.selectedClient && !this.state.isEditing) ?
            <ClientDetails client={this.state.selectedClient} deselect={this.deselectClient} />
            :
            <div>
              <h1>Clients</h1>
              <button onClick={this.startCreate}>Add Client</button>
              {
                this.state.isLoading ?
                  <Spinner />
                  :
                  (this.state.clients && this.state.clients.length > 0) ?
                    <ClientList clients={this.state.clients} delete={this.deleteClient} select={this.selectClient} edit={this.startEdit} />
                    :
                    <h3>No Clients Yet. Add one to get started!</h3>
              }
            </div>
        }
      </div>
    )
  }
}
