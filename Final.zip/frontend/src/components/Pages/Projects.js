import React from 'react'
import AuthContext from '../../context/auth-context'
import Modal from '../Modal'
import Backdrop from '../Backdrop'
import ProjectList from '../Projects/ProjectList'
import ProjectDetails from '../Projects/ProjectDetails'
import Spinner from '../Spinner'
import './index.css'

export default class Projects extends React.Component {
  static contextType = AuthContext
  constructor(props) {
    super(props)

    this.projectClientEl = React.createRef()
    this.projectNameEl = React.createRef()
    this.projectDescriptionEl = React.createRef()
    this.projectPaymentTypeEl = React.createRef()
    this.projectEstimatedHoursEl = React.createRef()
    this.projectRateEl = React.createRef()
    this.projectDueDateEl = React.createRef()
    this.projectTotalInvoicedEl = React.createRef()
    this.projectClosedEl = React.createRef()
  }

  state = {
    selectedProject: null,
    isEditing: false,
    isCreating: false,
    projects: [],
    type: 'Fixed',
    isLoading: false,
    clients: [] // for use when adding new projects
  }

  selectProject = id => {
    this.setState(prevState => {
      const selectedProject = prevState.projects.find(e => e.id === id)
      return { selectedProject }
    })
  }

  deselectProject = () => {
    this.setState({ selectedProject: null })
  }

  startCreate = () => {
    this.setState({ isCreating: true })
  }

  stopCreate = () => {
    this.setState({ isCreating: false })
  }

  addProject = () => {
    const body = {
      action: "addProject",
      creatorid: this.context.userId,
      clientid: this.projectClientEl.current.value,
      name: this.projectNameEl.current.value,
      description: this.projectDescriptionEl.current.value,
      estimatedhours: this.projectEstimatedHoursEl.current.value,
      rate: this.projectRateEl.current.value,
      paymenttype: this.projectPaymentTypeEl.current.value,
      duedate: this.projectDueDateEl.current.value ? this.projectDueDateEl.current.value : "null"
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { projects: prevState.projects.concat(resData), isCreating: false }
          })
        }
      })
  }

  startEdit = id => {
    this.setState(prevState => {
      const selectedProject = prevState.projects.find(e => e.id === id)
      return { isEditing: true, selectedProject }
    })
  }

  stopEdit = () => {
    this.setState({ isEditing: false, selectedProject: null })
  }

  editProject = () => {
    const body = {
      action: "updateProject",
      id: this.state.selectedProject.id,
      clientid: this.projectClientEl.current.value,
      name: this.projectNameEl.current.value,
      description: this.projectDescriptionEl.current.value,
      estimatedhours: this.projectEstimatedHoursEl.current.value,
      rate: this.projectRateEl.current.value,
      paymenttype: this.projectPaymentTypeEl.current.value,
      totalinvoiced: this.projectTotalInvoicedEl.current.value,
      duedate: this.projectDueDateEl.current.value ? this.projectDueDateEl.current.value : "null",
      closed: this.projectClosedEl.current.checked ? 1 : 0
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        console.log(resData)
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { isEditing: false, selectedProject: null, projects: prevState.projects.map(project => project.id === prevState.selectedProject.id ? resData : project) }
          })
        }
      })
  }

  deleteProject = id => {
    const body = {
      action: "deleteProject",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ projects: prevState.projects.filter(project => project.id !== id) }))
        }
      })
  }

  componentDidMount() {
    this.setState({ isLoading: true })
    let body = {
      action: "getProjects",
      options: {
        creatorId: this.context.userId
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ projects: resData })
        }
      })

    body = {
      action: "getClients",
      options: {
        creatorid: this.context.userId
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ clients: resData })
        }
      })
    this.setState({ isLoading: false })
  }

  render() {
    return (
      <div className="projects">
        { (this.state.isEditing || this.state.isCreating) && <Backdrop />}
        {/* The Create Project Modal */}
        {
          this.state.isCreating &&
          <Modal
            title="Add Project"
            canCancel
            canConfirm
            confirmText="Add"
            onCancel={this.stopCreate}
            onConfirm={this.addProject}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="projectClient">Client</label>
                <select type="text" name="projectClient" ref={this.projectClientEl} required>
                  {this.state.clients.map(client => <option key={client.id} value={client.id}>{client.clientname}</option>)}
                </select>
              </div>

              <div className="form-control">
                <label htmlFor="projectName">Name</label>
                <input type="text" name="projectName" ref={this.projectNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectDescription">Description</label>
                <input type="text" name="projectDescription" ref={this.projectDescriptionEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectPaymentType">Payment Type</label>
                <select type="text" name="projectPaymentType" ref={this.projectPaymentTypeEl} required onChange={e => this.setState({ type: e.target.value })}>
                  <option value="Fixed">Fixed</option>
                  <option value="Hourly">Hourly</option>
                </select>
              </div>

              {
                this.state.type === 'Fixed' ?
                  <div className="form-control">
                    <input type="hidden" name="projectEstimatedHours" value="1" ref={this.projectEstimatedHoursEl} />

                    <label htmlFor="projectRate">Project Payment</label>
                    <input type="number" name="projectRate" ref={this.projectRateEl} required />
                  </div>
                  :
                  <div>

                    <div className="form-control">
                      <label htmlFor="projectRate">Estimated Hours</label>
                      <input type="number" name="projectEstimatedHours" ref={this.projectEstimatedHoursEl} />
                    </div>

                    <div className="form-control">
                      <label htmlFor="projectRate">Rate</label>
                      <input type="number" name="projectRate" ref={this.projectRateEl} required />
                    </div>

                  </div>
              }

              <div className="form-control">
                <label htmlFor="projectDueDate">Due Date</label>
                <input type="date" name="projectDueDate" ref={this.projectDueDateEl} required />
              </div>

            </form>
          </Modal>
        }

        {/* The Edit Project Modal */}
        {
          (this.state.isEditing && this.state.selectedProject) &&
          <Modal
            title={"Edit Project"}
            canCancel
            canConfirm
            confirmText="Save"
            onCancel={this.stopEdit}
            onConfirm={this.editProject}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="projectClient">Client</label>
                <select type="text" name="projectClient" defaultValue={this.state.selectedProject.clientId} ref={this.projectClientEl} required>
                  {this.state.clients.map(client => <option key={client.id} value={client.id}>{client.clientname}</option>)}
                </select>
              </div>

              <div className="form-control">
                <label htmlFor="projectName">Name</label>
                <input type="text" defaultValue={this.state.selectedProject.name} name="projectName" ref={this.projectNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectDescription">Description</label>
                <input type="text" defaultValue={this.state.selectedProject.description} name="projectDescription" ref={this.projectDescriptionEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectPaymentType">Payment Type</label>
                <select type="text" name="projectPaymentType" defaultValue={this.state.selectedProject.paymentType} ref={this.projectPaymentTypeEl} required onChange={e => this.setState({ type: e.target.value })}>
                  <option value="Fixed">Fixed</option>
                  <option value="Hourly">Hourly</option>
                </select>

                {
                  this.state.type === 'Fixed' ?
                    <div className="form-control">
                      <input type="hidden" name="projectEstimatedHours" value="1" ref={this.projectEstimatedHoursEl} />

                      <label htmlFor="projectRate">Project Payment</label>
                      <input type="number" name="projectRate" defaultValue={this.state.selectedProject.rate} ref={this.projectRateEl} required />
                    </div>
                    :
                    <div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Estimated Hours</label>
                        <input type="number" name="projectEstimatedHours" defaultValue={this.state.selectedProject.estimatedHours} ref={this.projectEstimatedHoursEl} />
                      </div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Rate</label>
                        <input type="number" name="projectRate" defaultValue={this.state.selectedProject.rate} ref={this.projectRateEl} required />
                      </div>

                    </div>
                }

                <div className="form-control">
                  <label htmlFor="projectRate">Total Invoiced</label>
                  <input type="number" name="projectRate" defaultValue={this.state.selectedProject.totalInvoiced} ref={this.projectTotalInvoicedEl} required />
                </div>

                <div className="form-control">
                  <label htmlFor="projectDueDate">Due Date</label>
                  <input type="date" name="projectDueDate" defaultValue={Date(this.state.selectedProject.dueDate)} ref={this.projectDueDateEl} required />
                </div>

                <div className="form-control">
                  <label htmlFor="contactMain">Closed? </label>
                  <input type="checkbox" name="contactMain" defaultChecked={this.state.selectedProject.closed === "1"} ref={this.projectClosedEl} required />
                </div>

              </div>
            </form>
          </Modal>
        }

        {
          this.state.isLoading ?
            <Spinner />
            :
            (this.state.selectedProject && !this.state.isEditing) ?
              <ProjectDetails project={this.state.selectedProject} deselect={this.deselectProject} />
              :
              <div>
                <h1>Projects</h1>
                <button onClick={this.startCreate}>Add Project</button>
                {
                  (this.state.projects && this.state.projects.length > 0) ?
                    <ProjectList projects={this.state.projects} delete={this.deleteProject} select={this.selectProject} edit={this.startEdit} />
                    :
                    <h3>No Projects Yet. Add one to get started!</h3>
                }
              </div>

        }
      </div>
    )
  }
}