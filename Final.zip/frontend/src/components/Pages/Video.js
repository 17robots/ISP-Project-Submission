import React from 'react'

const Video = () => (
  <div>
    <h1> Client Management Service Video Demo </h1>
    <section>
      <video controls>
        <source src="video.mp4" width="800" height="600" type="video/mp4" />
      </video>
    </section>
  </div>
)

export default Video;

