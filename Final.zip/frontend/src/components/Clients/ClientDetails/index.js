import React from 'react'
import Backdrop from '../../Backdrop'
import Modal from '../../Modal/'
import AuthContext from '../../../context/auth-context'

export default class ClientDetails extends React.Component {
  static contextType = AuthContext

  constructor(props) {
    super(props)
    this.contactFirstNameEl = React.createRef()
    this.contactLastNameEl = React.createRef()
    this.contactPhoneEl = React.createRef()
    this.contactEmailEl = React.createRef()
    this.contactMainEl = React.createRef()

    this.projectNameEl = React.createRef()
    this.projectDescriptionEl = React.createRef()
    this.projectPaymentTypeEl = React.createRef()
    this.projectEstimatedHoursEl = React.createRef()
    this.projectRateEl = React.createRef()
    this.projectDueDateEl = React.createRef()
    this.projectTotalInvoicedEl = React.createRef()
    this.projectClosedEl = React.createRef()
  }

  state = {
    contacts: [],
    selectedContact: null,
    selectedProject: null,
    projects: [],
    isEditingContact: false,
    isCreatingContact: false,
    isEditingProject: false,
    isCreatingProject: false,
    type: 'Fixed'
  }

  startCreateContact = () => {
    this.setState({ isCreatingContact: true })

  }

  stopCreateContact = () => {
    this.setState({ isCreatingContact: false })
  }

  addContact = () => {
    const body = {
      action: "addContact",
      creatorid: this.context.userId,
      clientid: this.props.client.id,
      firstname: this.contactFirstNameEl.current.value,
      lastname: this.contactLastNameEl.current.value,
      email: this.contactEmailEl.current.value,
      phone: this.contactPhoneEl.current.value,
      maincontact: this.contactMainEl.current.checked ? 1 : 0
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { contacts: prevState.contacts.concat(resData), isCreatingContact: false }
          })
        }
      })
  }

  startEditContact = id => {
    this.setState(prevState => {
      const selectedContact = prevState.contacts.find(e => e.id === id)
      return { isEditingContact: true, selectedContact }
    })

  }

  stopEditContact = () => {
    this.setState({ isEditingContact: false })

  }

  editContact = () => {
    const body = {
      action: "updateContact",
      id: this.state.selectedContact.id,
      creatorid: this.context.userId,
      clientid: this.props.client.id,
      firstname: this.contactFirstNameEl.current.value,
      lastname: this.contactLastNameEl.current.value,
      email: this.contactEmailEl.current.value,
      phone: this.contactPhoneEl.current.value,
      maincontact: this.contactMainEl.current.checked ? 1 : 0
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { isEditingContact: false, contacts: prevState.contacts.map(contact => contact.id === prevState.selectedContact.id ? resData : contact) }
          })
        }
      })

  }

  deleteContact = id => {
    const body = {
      action: "deleteContact",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ contacts: prevState.contacts.filter(contact => contact.id !== id) }))
        }
      })
  }

  startCreateProject = () => {
    this.setState({ isCreatingProject: true })
  }

  stopCreateProject = () => {
    this.setState({ isCreatingProject: false })
  }

  addProject = () => {
    const body = {
      action: "addProject",
      creatorid: this.context.userId,
      clientid: this.props.client.id,
      name: this.projectNameEl.current.value,
      description: this.projectDescriptionEl.current.value,
      estimatedhours: this.projectEstimatedHoursEl.current.value,
      rate: this.projectRateEl.current.value,
      paymenttype: this.projectPaymentTypeEl.current.value,
      duedate: this.projectDueDateEl.current.value
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { projects: prevState.projects.concat(resData), isCreatingProject: false }
          })
        }
      })
  }

  startEditProject = id => {
    this.setState(prevState => {
      const selectedProject = prevState.projects.find(e => e.id === id)
      return { isEditingProject: true, selectedProject }
    })
  }

  stopEditProject = () => {
    this.setState({ isEditingProject: false })
  }

  editProject = () => {
    const body = {
      action: "updateProject",
      id: this.state.selectedProject.id,
      clientid: this.props.client.id,
      name: this.projectNameEl.current.value,
      description: this.projectDescriptionEl.current.value,
      estimatedhours: this.projectEstimatedHoursEl.current.value,
      rate: this.projectRateEl.current.value,
      paymenttype: this.projectPaymentTypeEl.current.value,
      totalinvoiced: this.projectTotalInvoicedEl.current.value,
      duedate: this.projectDueDateEl.current.value,
      closed: this.projectClosedEl.current.checked ? 1 : 0
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        console.log(resData)
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => {
            return { isEditingProject: false, selectedProject: null, projects: prevState.projects.map(project => project.id === prevState.selectedProject.id ? resData : project) }
          })
        }
      })
  }

  deleteProject = id => {
    const body = {
      action: "deleteProject",
      id
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState(prevState => ({ projects: prevState.projects.filter(project => project.id !== id) }))
        }
      })
  }

  deselect = e => {
    this.props.deselect()
    e.stopPropagation()
  }

  componentDidMount() {
    // here we fetch the contacts and the projects from the db
    let body = {
      action: "getContacts",
      options: {
        clientid: this.props.client.id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ contacts: resData })
        }
      })

    body = {
      action: "getProjects",
      options: {
        clientId: this.props.client.id
      }
    }

    fetch('http://localhost/isp/project/controller/Controller.php', {
      method: 'POST',
      body: JSON.stringify(body),
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    })
      .then(res => res.json())
      .then(resData => {
        if (resData.error) {
          alert(resData.error)
        } else {
          this.setState({ projects: resData })
        }
      })
  }

  render() {
    return (
      <div className="client-details">
        { (this.state.isCreatingContact || this.state.isCreatingProject || (this.state.isEditingProject && this.state.selectedProject) || (this.state.isEditingContact && this.state.selectedContact)) && <Backdrop />}
        {/* Add Contact Modal */}
        {
          this.state.isCreatingContact &&
          <Modal
            title="Add Contact"
            canCancel
            canConfirm
            confirmText="Add"
            onCancel={this.stopCreateContact}
            onConfirm={this.addContact}
          >
            <form className="input-form">
              <div className="form-control">
                <label htmlFor="contactFirstName">First Name</label>
                <input type="text" name="contactFirstName" ref={this.contactFirstNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactLastName">Last Name</label>
                <input type="text" name="contactLastName" ref={this.contactLastNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactEmail">Email</label>
                <input type="text" name="contactEmail" ref={this.contactEmailEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactPhone">Phone</label>
                <input type="text" name="contactPhone" ref={this.contactPhoneEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactMain">Main Contact? </label>
                <input type="checkbox" name="contactMain" ref={this.contactMainEl} required />
              </div>

            </form>
          </Modal>
        }
        {
          (this.state.isEditingContact && this.state.selectedContact) &&
          <Modal
            title="Edit Contact"
            canCancel
            canConfirm
            confirmText="Save"
            onCancel={this.stopEditContact}
            onConfirm={this.editContact}
          >
            <form className="input-form">
              <div className="form-control">
                <label htmlFor="contactFirstName">First Name</label>
                <input type="text" name="contactFirstName" defaultValue={this.state.selectedContact.firstname} ref={this.contactFirstNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactLastName">Last Name</label>
                <input type="text" name="contactLastName" defaultValue={this.state.selectedContact.lastname} ref={this.contactLastNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactEmail">Email</label>
                <input type="text" name="contactEmail" defaultValue={this.state.selectedContact.email} ref={this.contactEmailEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactPhone">Phone</label>
                <input type="text" name="contactPhone" defaultValue={this.state.selectedContact.phone} ref={this.contactPhoneEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="contactMain">Main Contact? </label>
                <input type="checkbox" name="contactMain" defaultChecked={this.state.selectedContact.maincontact} ref={this.contactMainEl} required />
              </div>

            </form>
          </Modal>
        }
        {
          this.state.isCreatingProject &&
          <Modal
            title={"Add Project for " + this.props.client.clientname}
            canCancel
            canConfirm
            confirmText="Add"
            onCancel={this.stopCreateProject}
            onConfirm={this.addProject}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="projectName">Name</label>
                <input type="text" name="projectName" ref={this.projectNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectDescription">Description</label>
                <input type="text" name="projectDescription" ref={this.projectDescriptionEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectPaymentType">Payment Type</label>
                <select type="text" name="projectPaymentType" ref={this.projectPaymentTypeEl} required onChange={e => this.setState({ type: e.target.value })}>
                  <option value="Fixed">Fixed</option>
                  <option value="Hourly">Hourly</option>
                </select>

                {
                  this.state.type === 'Fixed' ?
                    <div className="form-control">
                      <input type="hidden" name="projectEstimatedHours" value="1" ref={this.projectEstimatedHoursEl} />

                      <label htmlFor="projectRate">Project Payment</label>
                      <input type="number" name="projectRate" ref={this.projectRateEl} required />
                    </div>
                    :
                    <div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Estimated Hours</label>
                        <input type="number" name="projectEstimatedHours" ref={this.projectEstimatedHoursEl} />
                      </div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Rate</label>
                        <input type="number" name="projectRate" ref={this.projectRateEl} required />
                      </div>

                    </div>
                }

                <div className="form-control">
                  <label htmlFor="projectDueDate">Due Date</label>
                  <input type="date" name="projectDueDate" ref={this.projectDueDateEl} required />
                </div>

              </div>
            </form>
          </Modal>
        }
        {
          (this.state.isEditingProject && this.state.selectedProject) &&
          <Modal
            title={"Edit Project for " + this.props.client.clientname}
            canCancel
            canConfirm
            confirmText="Save"
            onCancel={this.stopEditProject}
            onConfirm={this.editProject}
          >
            <form className="input-form">

              <div className="form-control">
                <label htmlFor="projectName">Name</label>
                <input type="text" defaultValue={this.state.selectedProject.name} name="projectName" ref={this.projectNameEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectDescription">Description</label>
                <input type="text" defaultValue={this.state.selectedProject.description} name="projectDescription" ref={this.projectDescriptionEl} required />
              </div>

              <div className="form-control">
                <label htmlFor="projectPaymentType">Payment Type</label>
                <select type="text" name="projectPaymentType" defaultValue={this.state.selectedProject.paymentType} ref={this.projectPaymentTypeEl} required onChange={e => this.setState({ type: e.target.value })}>
                  <option value="Fixed">Fixed</option>
                  <option value="Hourly">Hourly</option>
                </select>

                {
                  this.state.type === 'Fixed' ?
                    <div className="form-control">
                      <input type="hidden" name="projectEstimatedHours" value="1" ref={this.projectEstimatedHoursEl} />

                      <label htmlFor="projectRate">Project Payment</label>
                      <input type="number" name="projectRate" defaultValue={this.state.selectedProject.rate} ref={this.projectRateEl} required />
                    </div>
                    :
                    <div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Estimated Hours</label>
                        <input type="number" name="projectEstimatedHours" defaultValue={this.state.selectedProject.estimatedHours} ref={this.projectEstimatedHoursEl} />
                      </div>

                      <div className="form-control">
                        <label htmlFor="projectRate">Rate</label>
                        <input type="number" name="projectRate" defaultValue={this.state.selectedProject.rate} ref={this.projectRateEl} required />
                      </div>

                    </div>
                }

                <div className="form-control">
                  <label htmlFor="projectRate">Total Invoiced</label>
                  <input type="number" name="projectRate" defaultValue={this.state.selectedProject.totalInvoiced} ref={this.projectTotalInvoicedEl} required />
                </div>

                <div className="form-control">
                  <label htmlFor="projectDueDate">Due Date</label>
                  <input type="date" name="projectDueDate" defaultValue={Date(this.state.selectedProject.dueDate)} ref={this.projectDueDateEl} required />
                </div>

                <div className="form-control">
                  <label htmlFor="contactMain">Closed? </label>
                  <input type="checkbox" name="contactMain" defaultChecked={this.state.selectedProject.closed === "1"} ref={this.projectClosedEl} required />
                </div>

              </div>
            </form>
          </Modal>
        }
        <button onClick={(e) => this.deselect(e)}>Back</button>
        <h1>{this.props.client.clientname}</h1>
        <h3>Phone: {this.props.client.clientphone}</h3>
        <h3>Email: {this.props.client.clientemail}</h3>
        <h3>Address: {this.props.client.address}</h3>

        <h2>Contacts</h2>
        <button onClick={this.startCreateContact}>Add Contact</button>
        {
          (this.state.contacts && this.state.contacts.length > 0) ?
            <ul>
              {
                this.state.contacts.map(contact => {
                  return (
                    <li>
                      <p>{contact.firstname} {contact.lastname}</p>
                      <p>Phone: {contact.phone}</p>
                      <p>Email: {contact.email}</p>
                      {contact.maincontact ? <p>Main Contact</p> : ''}
                      <button onClick={e => { this.startEditContact(contact.id); e.stopPropagation() }}>Edit</button>
                      <button onClick={e => { this.deleteContact(contact.id); e.stopPropagation() }}>Delete</button>
                    </li>
                  )
                }
                )
              }
            </ul>
            :
            <h3>No Contacts Yet</h3>
        }
        <h2>Projects</h2>
        <button onClick={this.startCreateProject}>Add Project</button>
        {
          (this.state.projects && this.state.projects.length > 0) ?
            <ul>
              {
                this.state.projects.map(project => {
                  return (
                    <li>
                      <p>{project.name}</p>
                      <p>{project.description}</p>
                      <p>Due: {project.dueDate}</p>
                      {project.closed === "1" ? <p>Closed</p> : ''}
                      <button onClick={e => { this.startEditProject(project.id); e.stopPropagation() }}>Edit</button>
                      <button onClick={e => { this.deleteProject(project.id); e.stopPropagation() }}>Delete</button>
                    </li>
                  )
                })
              }
            </ul>
            :
            <h3>No Projects For This Client</h3>
        }
      </div >
    )
  }
}