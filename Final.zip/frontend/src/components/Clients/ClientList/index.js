import React from 'react'

const clientList = props => {
  const handleDelete = (e, id) => {
    props.delete(id)
    e.stopPropagation()
  }

  const handleEdit = (e, id) => {
    props.edit(id)
    e.stopPropagation()
  }

  const handleSelect = (e, id) => {
    props.select(id)
    e.stopPropagation()
  }
  return (
    <ul>
      {
        props.clients.map(client => (
          <li key={client.id} onClick={e => handleSelect(e, client.id)}>
            <div>{client.clientname}</div>
            <div>
              <button onClick={e => handleEdit(e, client.id)}>Edit</button>
              <button onClick={e => handleDelete(e, client.id)}>Delete</button>
            </div>
          </li>
        ))
      }
    </ul>
  )
}

export default clientList