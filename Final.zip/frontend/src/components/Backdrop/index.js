import './index.css'

import React from 'react'

class Backdrop extends React.Component {
  render() {
    return (
      <div className="backdrop"></div>
    )
  }
}

export default Backdrop