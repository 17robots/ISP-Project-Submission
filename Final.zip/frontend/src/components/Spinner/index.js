import React from 'react'

import './index.css'

const spinner = () => (
  <div className="spinner">
    <div className="lds-dual-ring"></div>
  </div>
)

export default spinner